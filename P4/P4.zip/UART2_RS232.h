/* Funciones para trabajar con el modulo UART2_RS232.h
================================================

Autorxs: 
Fecha:
*/

// funciones que se utilizan desde otros modulos
void inic_UART2 ();
void enviar_UART2_ventana ();
void recibir_teclas (unsigned char num);


